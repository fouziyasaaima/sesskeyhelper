<?php
namespace local_sesskeyhelper\output;

use core\hook\output\before_http_headers as before_http_headers_hook;

defined('MOODLE_INTERNAL') || die();

class before_http_headers implements before_http_headers_hook {

    public function execute(): void {
        global $PAGE, $USER;

        if (!isloggedin() || isguestuser()) {
            return;
        }

        $sesskey = sesskey();

        $js = <<<EOD
document.addEventListener("DOMContentLoaded", function () {
    var sesskey = "{$sesskey}";

    document.querySelectorAll("form").forEach(function(form) {
        if (
            form.method.toLowerCase() === "post" &&
            !form.querySelector('[name="sesskey"]')
        ) {
            var input = document.createElement("input");
            input.type = "hidden";
            input.name = "sesskey";
            input.value = sesskey;
            form.appendChild(input);
        }
    });
});
EOD;

        $PAGE->requires->js_amd_inline($js);
    }
}
