<?php
defined('MOODLE_INTERNAL') || die();

$plugin->component = 'local_sesskeyhelper';
$plugin->version   = 2025062600;
$plugin->requires  = 2023042400; // Moodle 4.2+
$plugin->maturity  = MATURITY_STABLE;
$plugin->release   = '1.0';
