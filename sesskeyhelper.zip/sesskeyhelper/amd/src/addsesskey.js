// File: yourplugin/amd/src/addsesskey.js
define(['core/config'], function(config) {
    return {
        init: function () {
            if (!config.sesskey) {
                return;
            }

            document.querySelectorAll("form").forEach(function(form) {
                if (
                    form.method.toLowerCase() === "post" &&
                    !form.querySelector('[name="sesskey"]')
                ) {
                    var input = document.createElement("input");
                    input.type = "hidden";
                    input.name = "sesskey";
                    input.value = config.sesskey;
                    form.appendChild(input);
                }
            });
        }
    };
});
