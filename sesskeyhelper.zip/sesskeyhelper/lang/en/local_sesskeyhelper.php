<?php
$string['pluginname'] = 'Sesskey Helper';